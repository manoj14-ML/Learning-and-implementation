﻿Imports Microsoft.Office.Interop.Outlook
Imports Microsoft.Office.Interop
Imports Microsoft.Office
Imports Microsoft
Imports System.Net.Mail
Imports System.Data.SqlClient
Imports System.IO
Imports System
Imports System.Configuration
Imports System.Globalization
Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Windows.Forms
Imports Microsoft.Win32         'For System Events
Imports System.Management
Public Class CRUISE
    Dim Constring As String = ConfigurationManager.ConnectionStrings("Citeline.My.MySettings.Citeline").ConnectionString
    Dim cn As New SqlConnection(Constring)
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim LastKey As Keys
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Activate()
    End Sub

    Private Sub CRUISE_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If Me.Label3.Text = "No" Then

            Dim KD As Integer = Me.Label1.Text
            If LastKey = e.KeyCode Then
                Me.Label1.Text = Me.Label1.Text + 1
            Else
                Me.Label1.Text = 0
            End If
            LastKey = e.KeyCode

            If Me.Label1.Text > 500 Then
                Dim ol As New Outlook.Application()
                Dim ns As Outlook.NameSpace
                Dim fdMail As Outlook.MAPIFolder
                ns = ol.GetNamespace("MAPI")
                ns.Logon("", "", True, True)
                Dim newMail As Outlook.MailItem
                'gets defaultfolder for my Outlook Outbox
                fdMail = ns.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderOutbox)
                'assing values to the new mail mailitem
                newMail = fdMail.Items.Add(Outlook.OlItemType.olMailItem)
                With newMail
                    Dim Message = "<body bgcolor = #FFFFFF><center><img src='\\ctsincdcntapp12\Lavender\Citeline\CMB&HYDOps\Informa-CRUISETool\OneClick_Agent\Mailbody\Violation.jpg'></center> </body>"
                    newMail.Subject = "Agent involved in violation of the CRUISE application"
                    newMail.HTMLBody = Message
                    newMail.To = Me.Label2.Text
                    newMail.CC = Environment.UserName.ToString
                    'newMail.SaveSentMessageFolder = fdMail
                    newMail.Importance = Outlook.OlImportance.olImportanceHigh
                    newMail.Send()
                End With
                Me.Label1.Text = 0
                Me.Label3.Text = "Yes"
            End If

        End If
    End Sub

    Private Sub CRUISE_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Visible = True
        Dim x As Integer
        Dim y As Integer
        x = Screen.PrimaryScreen.WorkingArea.Width
        y = Screen.PrimaryScreen.WorkingArea.Height - Me.Height
        Do Until x = Screen.PrimaryScreen.WorkingArea.Width - Me.Width
            x = x - 1
            Me.Location = New Point(x, y)
        Loop
        cmd.Connection = cn
        cn.Open()
        cmd.CommandText = "select Supervisor_ID from Login where (EmpId = @LoginID)"
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
        dr = cmd.ExecuteReader()
        While (dr.Read())
            Me.Label2.Text = If(IsDBNull(dr.GetValue(0)), String.Empty, dr.GetValue(0))
        End While
        cn.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Master.Activate()
    End Sub
End Class