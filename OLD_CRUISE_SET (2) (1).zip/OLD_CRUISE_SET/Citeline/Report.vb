﻿Imports Microsoft.Reporting.WinForms
Imports System.Data.SqlClient
Imports System.IO

Public Class Report

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Me.Master1TableAdapter.Fill(Me.InformaDataSet.Master1)
            Dim fromdate As New ReportParameter("Fdate", DateTimePicker1.Value.ToString("yyyy-MM-dd"))
            Dim todate As New ReportParameter("Tdate", DateTimePicker2.Value.ToString("yyyy-MM-dd"))
            Dim Analyst As New ReportParameter("Analyst", Environment.UserName)
            ReportViewer1.LocalReport.SetParameters(New ReportParameter() {fromdate, todate, Analyst})
            ReportViewer1.RefreshReport()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
        End Try
    End Sub
End Class