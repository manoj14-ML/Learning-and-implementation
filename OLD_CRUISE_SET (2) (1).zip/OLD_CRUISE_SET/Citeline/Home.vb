﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Configuration
Imports System.Globalization
Imports System.Runtime.InteropServices
Imports System.Threading
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.Web
Imports Newtonsoft.Json.Linq
Imports System.Text.RegularExpressions
Imports System.Net.Http.Headers
Imports System.Net.Http

Public Class Home
    Dim Constring As String = ConfigurationManager.ConnectionStrings("Citeline.My.MySettings.Citeline").ConnectionString
    Dim cn As New SqlConnection(Constring)
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Private Async Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Using client As HttpClient = New HttpClient()
                'client.BaseAddress = New Uri("https://localhost:44321/")
                Using response As HttpResponseMessage = Await client.GetAsync("https://localhost:44321/api/Logins/", Environment.UserName.Trim)
                    Using content As HttpContent = response.Content
                        Dim result As String = Await content.ReadAsStringAsync()
                        Me.Label7.Text = result
                    End Using
                End Using
            End Using
            'cmd.Connection = cn
            'cn.Open()
            'cmd.CommandText = "select * from Login where (EmpId = @LoginID)"
            'cmd.Parameters.Clear()
            'cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
            'dr = cmd.ExecuteReader()
            'While (dr.Read())
            '    Me.Label7.Text = If(IsDBNull(dr.GetValue(1)), String.Empty, dr.GetValue(1))
            'End While
            'cn.Close()
            If Me.Label7.Text = Nothing Then
                Denied.Show()
                Me.Hide()
                Me.Timer1.Enabled = False
            Else
                Master.Show()
                Me.Hide()
                Shell("cmd.exe /c powercfg -change -monitor-timeout-ac 180") ' 3 Hours Turn off Sleep
                Shell("cmd.exe /c powercfg -change -standby-timeout-ac 180") '3 Hours Turn off Sleep
                Me.Timer1.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

End Class
