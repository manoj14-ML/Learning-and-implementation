﻿Imports System.Data.SqlClient
Imports System.IO
Imports System
Imports System.Configuration
Imports System.Globalization
Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Windows.Forms
Imports Microsoft.Win32         'For System Events
Imports System.Management


Public Class Master
    Dim Constring As String = ConfigurationManager.ConnectionStrings("Citeline.My.MySettings.Citeline").ConnectionString
    Dim cn As New SqlConnection(Constring)
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Private Declare Function ExitWindowsEx Lib "user32" (ByVal dwOptions As Integer, ByVal dwReserved As Integer) As Integer

    Private stopwatch As New Stopwatch
    Private stopwatch1 As New Stopwatch
    Private stopwatch2 As New Stopwatch
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Private Declare Function GetLastInputInfo Lib "User32.dll" _
      (ByRef lastInput As LASTINPUTINFO) As Boolean
    'Create structure for time
     _
    Public Structure LASTINPUTINFO
        Public cbSize As Int32
        Public dwTime As Int32
    End Structure

    Private Sub Master_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Label2.Text = DateAndTime.Now.ToString
            Dim reqstdate As String = Format(Date.Now, "yyyyMMdd").ToString
            Me.Label23.Text = My.Computer.Name
            cmd.Connection = cn
            cn.Open()
            cmd.CommandText = "select * from Master1 where (Empid = @LoginID and Ldate = @Date)"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
            cmd.Parameters.AddWithValue("@Date", reqstdate)
            dr = cmd.ExecuteReader()
            While (dr.Read())
                Me.Label16.Text = If(IsDBNull(dr.GetValue(1)), String.Empty, dr.GetValue(1))
            End While
            cn.Close()
            If Me.Label16.Text = "ID" Then
                cn.Open()
                cmd.CommandText = "select * from Login where (EmpId = @LoginID)"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
                dr = cmd.ExecuteReader()
                While (dr.Read())
                    Me.Label1.Text = If(IsDBNull(dr.GetValue(1)), String.Empty, dr.GetValue(1))
                    Me.Label9.Text = If(IsDBNull(dr.GetValue(6)), String.Empty, dr.GetValue(6))
                    Me.Label11.Text = If(IsDBNull(dr.GetValue(7)), String.Empty, dr.GetValue(7))
                    Me.Label10.Text = If(IsDBNull(dr.GetValue(5)), String.Empty, dr.GetValue(5))
                    Me.Label12.Text = If(IsDBNull(dr.GetValue(9)), String.Empty, dr.GetValue(9))
                    Me.Label13.Text = If(IsDBNull(dr.GetValue(4)), String.Empty, dr.GetValue(4))
                End While
                cn.Close()
                If Me.Label1.Text = Nothing Then
                    Me.Hide()
                    Denied.Show()
                Else
                    cn.Open()
                    cmd.CommandText = "insert into Master1 (Version,PC,Designation,Name,Empid,Ldate,Login,Location,Process,Subprocess)Values(@Version,@PC,@Designation,@Name,@LoginID,@Ldate,@Login,@Location,@Process,@Subprocess)"
                    cmd.Parameters.Clear()
                    cmd.Parameters.AddWithValue("@Name", Label1.Text)
                    cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
                    cmd.Parameters.AddWithValue("@Ldate", reqstdate)
                    cmd.Parameters.AddWithValue("@Login", Label2.Text)
                    cmd.Parameters.AddWithValue("@Location", Label12.Text)
                    cmd.Parameters.AddWithValue("@Process", Label9.Text)
                    cmd.Parameters.AddWithValue("@Subprocess", Label11.Text)
                    cmd.Parameters.AddWithValue("@Designation", Label10.Text)
                    cmd.Parameters.AddWithValue("@PC", Me.Label23.Text)
                    cmd.Parameters.AddWithValue("@Version", "V1.3.5")
                    cmd.ExecuteNonQuery()
                    cn.Close()
                End If
            Else
                cn.Open()
                cmd.CommandText = "select * from Master1 where (Empid = @LoginID3 and Ldate = @Date3)"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@LoginID3", Environment.UserName.Trim)
                cmd.Parameters.AddWithValue("@Date3", reqstdate)
                dr = cmd.ExecuteReader()
                While (dr.Read())
                    Me.Label1.Text = If(IsDBNull(dr.GetValue(1)), String.Empty, dr.GetValue(1))
                    Me.Label12.Text = If(IsDBNull(dr.GetValue(10)), String.Empty, dr.GetValue(10))
                    Me.Label9.Text = If(IsDBNull(dr.GetValue(11)), String.Empty, dr.GetValue(11))
                    Me.Label11.Text = If(IsDBNull(dr.GetValue(12)), String.Empty, dr.GetValue(12))
                    Me.Label10.Text = If(IsDBNull(dr.GetValue(13)), String.Empty, dr.GetValue(13))
                    Me.Label2.Text = Convert.ToDateTime(dr.GetValue(3))
                    Me.Label17.Text = If(IsDBNull(dr.GetValue(5)), 0, dr.GetValue(5))
                    Me.Label19.Text = If(IsDBNull(dr.GetValue(14)), 0, dr.GetValue(14))
                End While
                cn.Close()
            End If
            Me.Timer5.Enabled = True
            CRUISE.Show()
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Dim lastInput As New LASTINPUTINFO
            lastInput.cbSize = Marshal.SizeOf(lastInput)
            If GetLastInputInfo(lastInput) Then
                '60 it means 1 minute, on each timer tick code verify user is ideal from last 1 min
                If (1 <= (Environment.TickCount - lastInput.dwTime) / 300000) Then ' 90 Secs
                    'Here you can do anything when user is ideal from your specific time
                    Me.Label7.Text = 2 'Status Code
                    Me.Label3.ForeColor = Color.Red
                    Me.Label5.ForeColor = Color.YellowGreen
                    Dim i As Integer
                    Me.Label17.Text = Me.Label15.Text - Me.Label19.Text
                    i = Integer.Parse(Me.Label17.Text)
                    i = i + 1
                    Me.Label17.Text = i.ToString
                    Dim minutes As Integer = Integer.Parse(Me.Label17.Text)
                    Dim ts As New TimeSpan(0, 0, minutes)
                    Label3.Text = String.Format("{0:00}:{1:00}:{2:00}", Math.Floor(ts.TotalHours), ts.Minutes, ts.Seconds)
                Else
                    Me.Label7.Text = 1 'Status Code
                    Me.Label3.ForeColor = Color.YellowGreen
                    Me.Label5.ForeColor = Color.DeepSkyBlue
                    Dim J As Integer
                    J = Integer.Parse(Me.Label19.Text)
                    J = J + 1
                    Me.Label19.Text = J.ToString
                    Dim minutes1 As Integer = Integer.Parse(Me.Label19.Text)
                    Dim ts1 As New TimeSpan(0, 0, minutes1)
                    Label5.Text = String.Format("{0:00}:{1:00}:{2:00}", Math.Floor(ts1.TotalHours), ts1.Minutes, ts1.Seconds)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Try
            Me.Label17.Text = Me.Label15.Text - Me.Label19.Text
            cmd.Connection = cn
            cn.Open()
            cmd.CommandText = "Update Master1 set CurrentDuration = @CurrentDuration,Version = @Version,PC = @PC, Staffed = @Staffed,Idle = @Idle,Active = @Active,Logout = @Logout,Status = @Status where Empid = @LoginID and Login = @Login"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@Idle", Label17.Text)
            cmd.Parameters.AddWithValue("@Active", Label19.Text)
            cmd.Parameters.AddWithValue("@Logout", Label4.Text)
            cmd.Parameters.AddWithValue("@Status", Label7.Text)
            cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
            cmd.Parameters.AddWithValue("@Login", Label2.Text)
            cmd.Parameters.AddWithValue("@Staffed", Me.Label20.Text)
            cmd.Parameters.AddWithValue("@PC", Me.Label23.Text)
            cmd.Parameters.AddWithValue("@Version", "V1.3.5")
            cmd.Parameters.AddWithValue("@CurrentDuration", Me.Label28.Text)
            cmd.ExecuteReader()
            cn.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Try
            Dim icode As DateTime = Me.Label28.Text
            Dim hrs As Integer = icode.Hour.ToString()
            If Me.Label7.Text = 2 Then
                If hrs >= 2 Then
                    Me.Timer1.Enabled = False
                    Me.Timer4.Enabled = False
                    Me.Timer9.Enabled = True
                    Me.Timer3.Enabled = False
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Label14_MouseMove(sender As Object, e As MouseEventArgs) Handles Label14.MouseMove
        Try
            If IsFormBeingDragged Then
                Dim temp As Point = New Point()
                temp.X = Me.Location.X + (e.X - MouseDownX)
                temp.Y = Me.Location.Y + (e.Y - MouseDownY)
                Me.Location = temp
                temp = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try
    End Sub

    Private Sub Label14_MouseUp_1(sender As Object, e As MouseEventArgs) Handles Label14.MouseUp
        Try
            If e.Button = MouseButtons.Left Then
                IsFormBeingDragged = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try
    End Sub

    Private Sub Label14_MouseDown_1(sender As Object, e As MouseEventArgs) Handles Label14.MouseDown
        Try
            If e.Button = MouseButtons.Left Then
                IsFormBeingDragged = True
                MouseDownX = e.X
                MouseDownY = e.Y
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        Try
            'End Date&time
            Me.Label4.Text = DateAndTime.Now.ToString

            'Progress bar
            If Me.ProgressBar1.Value = 30 Then
                Me.ProgressBar1.Value = 0
            Else
                Me.ProgressBar1.Increment(1)
            End If

            'Progress Circle
            Dim ii As Integer = Me.Label19.Text
            Dim K As Integer
            Dim j As Integer
            K = ((ii / 28800)) * 360  '8 Hours -  Active Time
            j = ((ii / 28800)) * 100  '8 Hours -  Active Time
            Me.Label21.Text = j.ToString("N2")
            Me.CircularProgressBar1.ProgressAngle = K.ToString

            'Subract End-Start

            Dim t1 As DateTime = Me.Label4.Text
            Dim t2 As DateTime = Me.Label2.Text
            Dim span As TimeSpan
            span = t1.Subtract(t2)
            Me.Label20.Text = span.ToString()
            Me.Label25.Text = span.Hours
            Me.Label15.Text = span.TotalSeconds ' Seconds

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try
    End Sub

    Private Sub Timer5_Tick(sender As Object, e As EventArgs) Handles Timer5.Tick
        Try
            Dim i As Integer
            i = Integer.Parse(Me.Label19.Text)
            Me.Label19.Text = i.ToString
            Dim minutes As Integer = Integer.Parse(Me.Label19.Text)
            Dim ts As New TimeSpan(0, 0, minutes)
            Label5.Text = String.Format("{0:00}:{1:00}:{2:00}", Math.Floor(ts.TotalHours), ts.Minutes, ts.Seconds)

            Dim j As Integer
            j = Integer.Parse(Me.Label17.Text)
            j = j + 1
            Me.Label17.Text = j.ToString
            Dim minutes1 As Integer = Integer.Parse(Me.Label17.Text)
            Dim ts1 As New TimeSpan(0, 0, minutes1)
            Label3.Text = String.Format("{0:00}:{1:00}:{2:00}", Math.Floor(ts1.TotalHours), ts1.Minutes, ts1.Seconds)
            Me.Timer5.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try
    End Sub

    Private Sub Timer6_Tick(sender As Object, e As EventArgs) Handles Timer6.Tick
        Try
            If My.Computer.Network.IsAvailable Then
                Me.Label22.Text = "Network Connected"
                Me.Label22.ForeColor = Color.GreenYellow
                Me.Timer2.Enabled = True
            Else
                Me.Label22.Text = "Network Not Connected"
                Me.Label22.ForeColor = Color.Red
                Me.Timer2.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Timer7_Tick(sender As Object, e As EventArgs) Handles Timer7.Tick
        Try
            Me.Label7.Text = 0
            Me.Label17.Text = Me.Label15.Text - Me.Label19.Text
            cmd.Connection = cn
            cn.Open()
            cmd.CommandText = "Update Master1 set CurrentDuration = @CurrentDuration,Staffed = @Staffed,Shut = @Shut,Idle = @Idle,Active = @Active,Logout = @Logout,Status = @Status where Empid = @LoginID and Login = @Login"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@Shut", "Man")
            cmd.Parameters.AddWithValue("@Idle", Label17.Text)
            cmd.Parameters.AddWithValue("@Active", Label19.Text)
            cmd.Parameters.AddWithValue("@Logout", Label4.Text)
            cmd.Parameters.AddWithValue("@Status", Label7.Text)
            cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
            cmd.Parameters.AddWithValue("@Login", Label2.Text)
            cmd.Parameters.AddWithValue("@Staffed", Me.Label20.Text)
            cmd.Parameters.AddWithValue("@CurrentDuration", "00:00:00")
            cmd.ExecuteReader()
            cn.Close()
            Shell("shutdown -S")
            Application.Exit()
        Catch ex As Exception
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub Master_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            'Me.Label7.Text = 0
            cmd.Connection = cn
            cn.Open()
            cmd.CommandText = "Update Master1 set CurrentDuration = @CurrentDuration,Status = @Status where Empid = @LoginID and Login = @Login"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@Status", 0)
            cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
            cmd.Parameters.AddWithValue("@Login", Label2.Text)
            cmd.Parameters.AddWithValue("@CurrentDuration", "00:00:00")
            cmd.ExecuteReader()
            cn.Close()
        Catch ex As Exception
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub Timer9_Tick(sender As Object, e As EventArgs) Handles Timer9.Tick
        Try
            'Me.Label7.Text = 0
            Dim lasttime As DateTime = DateAdd(DateInterval.Hour, -2, Now())
            Me.Label4.Text = lasttime

            Dim t1 As DateTime = Me.Label4.Text
            Dim t2 As DateTime = Me.Label2.Text
            Dim span As TimeSpan
            span = t1.Subtract(t2)
            Me.Label20.Text = span.ToString()

            Me.Label25.Text = span.Hours
            Me.Label15.Text = span.TotalSeconds 'Seconds

            Me.Label17.Text = Me.Label15.Text - Me.Label19.Text 'Idle
            'Dim Myidle As Integer = Me.Label17.Text
            'Dim Subtract1 As Integer
            'Subtract1 = Myidle - 7200 '7200

            cmd.Connection = cn
            cn.Open()
            cmd.CommandText = "Update Master1 set CurrentDuration = @CurrentDuration,ShutDT = @ShutDT,Staffed = @Staffed,Shut = @Shut,Idle = @Idle,Active = @Active,Logout = @Logout,Status = @Status where Empid = @LoginID and Login = @Login"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@Shut", "Aut")
            cmd.Parameters.AddWithValue("@Idle", Me.Label17.Text)
            cmd.Parameters.AddWithValue("@Active", Label19.Text)
            cmd.Parameters.AddWithValue("@Logout", Me.Label4.Text)
            cmd.Parameters.AddWithValue("@Status", 0)
            cmd.Parameters.AddWithValue("@LoginID", Environment.UserName.Trim)
            cmd.Parameters.AddWithValue("@Login", Label2.Text)
            cmd.Parameters.AddWithValue("@Staffed", Me.Label20.Text)
            cmd.Parameters.AddWithValue("@ShutDT", Now())
            cmd.Parameters.AddWithValue("@CurrentDuration", "00:00:00")
            cmd.ExecuteReader()
            cn.Close()
            Shell("shutdown -S")
            Application.Exit()
        Catch ex As Exception
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub
    Private Sub Timer11_Tick(sender As Object, e As EventArgs) Handles Timer11.Tick
        Try
            Dim elapsed2 As TimeSpan = Me.stopwatch.Elapsed
            Label28.Text = String.Format("{0:00}:{1:00}:{2:00}", Math.Floor(elapsed2.TotalHours), elapsed2.Minutes, elapsed2.Seconds)
            stopwatch.Start()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Label7_TextChanged(sender As Object, e As EventArgs) Handles Label7.TextChanged
        Try
            stopwatch.Reset()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Try
            Applicationexit.Show()
        Catch ex As Exception

        End Try
    End Sub

    'Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
    '    Try
    '        Report.Show()
    '    Catch ex As Exception

    '    End Try
    'End Sub

End Class