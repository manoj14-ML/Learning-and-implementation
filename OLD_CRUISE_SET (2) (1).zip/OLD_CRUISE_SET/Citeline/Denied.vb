﻿Public Class Denied
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Application.Exit()
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try
    End Sub
End Class